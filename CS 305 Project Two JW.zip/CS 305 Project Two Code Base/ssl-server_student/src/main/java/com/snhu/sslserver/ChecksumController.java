package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChecksumController {

    @GetMapping("/hash")
    public String getChecksum() {
        String data = "Hello World Check Sum! - Jaden Williams";
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            String checksum = Base64.getEncoder().encodeToString(hashBytes);

            return "Data: " + data + "\nSHA-256 Checksum: " + checksum;
        } catch (NoSuchAlgorithmException e) {
            return "Error computing checksum: " + e.getMessage();
        }
    }
}
